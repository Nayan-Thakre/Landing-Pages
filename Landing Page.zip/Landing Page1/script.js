var watch={
    price:"24k",
    Brand:"Armani",
    Digital:"Analog",
    color:"black",
    lerelundKe:function(){}
}
console.log(watch)
